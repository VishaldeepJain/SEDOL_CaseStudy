﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEDOL_CaseStudy;
using System;

namespace UnitTestSEDOL
{
    [TestClass]
    public class SEDOLUnitTest
    {
        [TestMethod]
        public void InValidInputTest()
        {
            ISedolValidator sedolValidator = new SedolValidator();
            ISedolValidationResult sedolValidationResult = sedolValidator.ValidateSedol(null);
            Assert.AreEqual(sedolValidationResult.ValidationDetails, "Input string was not 7-characters long");
        }

        [TestMethod]
        public void InValidInputTest_SpecialChar()
        {
            ISedolValidator sedolValidator = new SedolValidator();
            ISedolValidationResult sedolValidationResult = sedolValidator.ValidateSedol("12345%1");
            Assert.AreEqual(sedolValidationResult.ValidationDetails, "SEDOL contains invalid characters");
        }

        [TestMethod]
        public void InValidCheckSum_UserDefinedSEDOL()
        {
            ISedolValidator sedolValidator = new SedolValidator();
            ISedolValidationResult sedolValidationResult = sedolValidator.ValidateSedol("9ABCDE8");
            Assert.AreEqual(sedolValidationResult.ValidationDetails, "Checksum digit does not agree with the rest of the input");
            Assert.IsFalse(sedolValidationResult.IsValidSedol);
            Assert.IsTrue(sedolValidationResult.IsUserDefined);
        }

        [TestMethod]
        public void InValidCheckSum_NonUserDefinedSEDOL()
        {
            ISedolValidator sedolValidator = new SedolValidator();
            ISedolValidationResult sedolValidationResult = sedolValidator.ValidateSedol("1234567");
            Assert.AreEqual(sedolValidationResult.ValidationDetails, "Checksum digit does not agree with the rest of the input");
            Assert.IsFalse(sedolValidationResult.IsValidSedol);
            Assert.IsFalse(sedolValidationResult.IsUserDefined);
        }

        [TestMethod]
        public void ValidCheckSum_UserDefinedSEDOL()
        {
            ISedolValidator sedolValidator = new SedolValidator();
            ISedolValidationResult sedolValidationResult = sedolValidator.ValidateSedol("9ABCDE1");
            Assert.AreEqual(sedolValidationResult.ValidationDetails, "Null");
            Assert.IsTrue(sedolValidationResult.IsValidSedol);
            Assert.IsTrue(sedolValidationResult.IsUserDefined);
        }

        [TestMethod]
        public void ValidCheckSum_NonUserDefinedSEDOL()
        {
            ISedolValidator sedolValidator = new SedolValidator();
            ISedolValidationResult sedolValidationResult = sedolValidator.ValidateSedol("0709954");
            Assert.AreEqual(sedolValidationResult.ValidationDetails, "Null");
            Assert.IsTrue(sedolValidationResult.IsValidSedol);
            Assert.IsFalse(sedolValidationResult.IsUserDefined);
        }
    }
}
